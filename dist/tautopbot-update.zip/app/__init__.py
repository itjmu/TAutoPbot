"""Telegram automation application."""
